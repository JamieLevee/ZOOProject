public interface Feeding
{
    public String feed();
}