import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
public class ZooTester
{
    public static void main(String[] args) throws InterruptedException 
    {
        List<Animal> Animals = new ArrayList<>();

        System.out.println("Welcome to the Sports Zoo!");

        System.out.println("Turning on the lights");
        delayDots(3);

        System.out.println("Gearing up animals");
        delayDots(3);
        populateAnimals(Animals);

        System.out.println("Hiring Referees");
        delayDots(3);

        System.out.println("You stand inside of the Sports Zoo, what do you do?");
        System.out.println("Say 'help' if you need any help.");

        Scanner in = new Scanner(System.in);
        String text = in.nextLine();
        String msg = "";
        while (!text.equals ("leave"))
        {
            switch (text)
            {
                case "help":
                msg = "Just can visit cages, visit lunchtime, listen, look up, or go swimming!";
                break;

                case "visit cages":
                msg = visitCages(Animals);
                break;

                case "visit lunchtime":
                msg = visitLunch(Animals);
                break;

                case "listen":
                msg = toListen(Animals);
                break;

                case "look up":
                msg = lookUp(Animals);
                break;

                case "go swimming":
                msg = goSwimming(Animals);
                break;

                case "consessions":
                msg = "You purchase a sundae and eat it...";
                break;

                case "drinks":
                msg = "You purchase a soda and drink it...";
                break;

                case "food":
                msg = "You purchase a hotdog and eat it...";
                break;
                //nice
                case "tired": 
                msg = "You sit on a bench and rest...";
                break;

                case "stay until closing time":
                msg = "You wait several hours until it reaches closing time and then leave, having accomplished nothing...";
                break;

                case "activities":
                msg = "You can race, play soccer,or feed the animals.";
                break;

                case "soccer":
                msg = "You challenge the Goomba! It's coming at you with the ball! Move right or left?";
                break;

                case "left":
                msg = "You steal the ball and move forward! You're about to win! But the Goomba is behind you! Run or slow down?";
                break;

                case "right":
                msg = "You try to grab the ball and move right but you just fall down. You've lost, you fool.";
                break;

                case "slow down":
                msg = "The Goomba nearly trips over you in surprise! You rush ahead and win.";
                break;

                case "run":
                msg = "You run so fast that you fall and trip! The Goomba steals the ball and easily wins. Wow, you lost to a goomba.";
                break;

                case "race":
                msg = "You challenge the llama! However, you quickly lose after it spits at you in the face.";
                break;

                case "basketball":
                msg = "You challenge the Shark! It runs at you, but you, a mere pleb, cannot stop it.";
                break;

                case "hockey":
                msg = "The T-Rex begs to play against you. Accepting, you think that you'll win. However, you are eaten mid-game!";
                break;

                case "sports":
                msg = "You can try a lot of sports, but the chances of you winning are slim.";
                break;

                default: msg = "You think about what to do..";
            }
            System.out.println(msg);
            delayDots(3);
            System.out.println("What now?");
            text = in.nextLine();
        }
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for (int i=0; i<dotAmount; i++)  {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static void populateAnimals(List<Animal> Animals)
    {

        Monkey m = new Monkey();
        SunBear s = new SunBear();
        MourningDove d = new MourningDove();
        FruitBat f = new FruitBat();
        Bunny b = new Bunny();
        RedPanda r = new RedPanda();
        FleshMonster fl = new FleshMonster();
        Bokoblin bo = new Bokoblin();
        Platypus pl = new Platypus();
        Droid dr = new Droid();
        Anaconda a = new Anaconda();
        Thwomp t = new Thwomp();
        GoldFish g = new GoldFish();
        IronTarkus i = new IronTarkus();
        Abominablesnowman ab = new Abominablesnowman();
        Goomba go = new Goomba();
        Shark sh = new Shark();
        Rhino rh = new Rhino();
        Walter wa = new Walter();
        Lochnessmonster lo = new Lochnessmonster();
        Vince v = new Vince();
        Trex tr = new Trex();
        Llama ll = new Llama();
        Phish ph = new Phish();
        nakedMoleRats nmr = new nakedMoleRats();
        HomunculusFleshPuppet hfp = new HomunculusFleshPuppet();
        LR57CombatDroid lr = new LR57CombatDroid();
        Moblin mob = new Moblin();
        Bigfoot big = new Bigfoot();

        Animals.add(m);
        Animals.add(s);
        Animals.add(d);
        Animals.add(f);
        Animals.add(b);
        Animals.add(r);
        Animals.add(a);
        Animals.add(t);
        Animals.add(g);
        Animals.add(i);
        Animals.add(v);
        Animals.add(lr);
        Animals.add(ab);
        Animals.add(fl);
        Animals.add(bo);
        Animals.add(pl);
        Animals.add(dr);
        Animals.add(go);
        Animals.add(sh);
        Animals.add(rh);
        Animals.add(wa);
        Animals.add(lo);
        Animals.add(tr);
        Animals.add(ll);
        Animals.add(ph);
        Animals.add(nmr);
        Animals.add(hfp);
        Animals.add(mob);
        Animals.add(big);
    }

    public static String visitCages(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            msg += a.getName() + ": \n "
            + a.getDescription() + "\n";
        }
        return msg;
    }

    public static String visitLunch(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            msg += a.getName() +": \n" + a.eat();
        }
        return msg;
    }

    public static String toListen(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            msg +=  a.getName() + a.makeNoise() + "\n";
        }
        return msg;
    }

    public static String lookUp(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            if (a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + ": \n" + f.fly() + "\n";
            }
        }
        return msg;
    }

    public static String lookAround(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            if (a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n" + w.walk() + "\n";
            }
        }
        return msg;
    }

    public static String goSwimming(List <Animal> Animals)
    {
        String msg = "";
        for (Animal a : Animals)
        {
            if (a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ": \n" + s.swim() + "\n";
            }
        }
        return msg;
    }
}