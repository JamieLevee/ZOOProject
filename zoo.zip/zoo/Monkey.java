/**
 * Write a description of class Monkey here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Monkey extends Animal
    implements Walking

{
    public Monkey()
    {
        this("Diddy Kong", "Small and light, it'll destroy any plumber in the way.");
    }
    
    public Monkey(String name, String description) {
        super(name, description);
        //super calls the parent
    }
    
    @Override
    
    public String eat() {
        return "Eats fruit.";
    }
    
    @Override
    public String makeNoise() {
        return "OO! OO! A! A! *angry monkey noises*";
    }
    

    @Override
    public String walk() {
        return "*INTENSE RUNNING*";
    }
}
