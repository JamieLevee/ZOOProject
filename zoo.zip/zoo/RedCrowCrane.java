
/**
 * Write a description of class RedCrowCrane here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RedCrowCrane extends Animal implements Flying
{
    public RedCrowCrane()
    {
        this("Eiichi", "Being Humble ");
    }
    
    public RedCrowCrane(String name, String Decription)
    {
        super(name, Decription);
    }
    
    @Override
    
    public String makeNoise()
    {
       return "Caw Caw";
    }
    
    @Override
    
    public String eat()
    {
       return "*Gulp*";
    }
    
    @Override
    
    public String fly()
    {
       return "*Flap*";
    }
}
