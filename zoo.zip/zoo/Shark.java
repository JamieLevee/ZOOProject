
/**
 * Write a description of class shark here. - Eats fishes
 *
 * @author John Jagger
 * @version 1.0.1
 */
public class Shark extends Animal implements Walking, Swimming, Feeding
    
{
    // instance variables - replace the example below with your own
    public Shark()
    {
        this("Sushi the Great Shark", "I'ma eat Mario, Crunch Crunch");
    }
    public Shark(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "Chews on fish and Mario";
    }
    @Override
    public String makeNoise()
    {
        return "Blub, Blob";
    }
    @Override
    public String swim()
    {
        return "Swish Swash, bubble bubble";
    }
    @Override
    public String walk()
    {
        return "dead";
    }
    @Override
    public String feed()
    {
        return "It casually eats your leg.";
    }
}
